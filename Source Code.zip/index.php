<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>OneUiX | Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="icon" type="image/x-icon" href="logo.png">
  </head>
  <body>
    <?php
    if(isset($_POST["submit"])){
      require("mysql.php");
      $stmt = $mysql->prepare("SELECT * FROM accounts WHERE USERNAME = :user"); //Username überprüfen
      $stmt->bindParam(":user", $_POST["username"]);
      $stmt->execute();
      $count = $stmt->rowCount();
      if($count == 1){
        //Username ist frei
        $row = $stmt->fetch();
        if(password_verify($_POST["pw"], $row["PASSWORD"])){
          session_start();
          $_SESSION["username"] = $row["USERNAME"];
          header("Location: loading.php");
        } else {
          echo "Der Login ist fehlgeschlagen";
        }
      } else {
        echo "<p style='color:red; margin-top: 25%;'>Email or Password wrong!</p>";
      }
    }
     ?>
    
    <div class="form_div">
    <h1>Login</h1>
    <form action="index.php" method="post">
      <input type="email" name="username" placeholder="E-Mail" required>
      <br>
      <br>
      <input type="password" name="pw" placeholder="Password" required>
      <br>
      <br>
      <br>
      <button type="submit" name="submit" title="Login" ><i class="material-icons">login</i></button>
    </form>
    <br>
    <a href="register.php" title="Creating a new account"><i class="material-icons">group_add</i></a>
  </div>
  </body>
</html>
