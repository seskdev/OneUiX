document.addEventListener('DOMContentLoaded', function() {

    /* menu toggler */
    const menu = document.getElementById('menu');
    let direction; 
    document.addEventListener('keydown', function(e) {
        switch(e.keyCode) {
            case 27: // escape
                toggleMenu(menu);
                break;
            case 37: // left arrow
                direction = "left";
            case 39: // right arrow
                direction = direction || "right";
                break;
            case 38: // top arrow
                direction = "top";
            case 40: // bottom arrow
                direction = direction || "bottom";
            default:
                break;
        }
        if(direction && menu.classList.contains('active')) {
            e.preventDefault();
            moveNav(direction, menu);
            direction = null;
        }
    });
    menu.querySelector('.menu-overlay').addEventListener('click', function(e) {
        toggleMenu(menu);
    });
    menu.addEventListener('touchstart', handleTouchStart, false);  
    menu.addEventListener('touchmove', handleTouchMove, false);  
  
    /* active menu panel icon highlighter  */
    const menuLabels = document.querySelectorAll('#menu label');
    menuLabels.forEach(function(el, idx) {
        el.addEventListener('click', function(evt) {
            menuLabels.forEach(function(e,i) {
                if (e === el)
                    e.classList.add('active');
                else 
                    e.classList.toggle('active', false);
            });
        });
    });
    /* handle inner navigation Hover/arrow navigation */
    menu.querySelectorAll('.panel [data-nav-order]').forEach(function(element, index) {
        element.addEventListener('mouseover', function(e) {
            menu.querySelectorAll(':checked + .panel [data-nav-order]').forEach(function(el, idx) {
                if(el.isSameNode(e.currentTarget))
                    el.classList.add('hover');
                else 
                    el.classList.remove('hover');
            }); 
        });
    })

    /* custom scrollbar if needed */
    menu.querySelectorAll('.scrollable').forEach(function(el, idx) {
        yaSimpleScrollbar.attach(el);
    });
});

function toggleMenu(menu) {
    const menuOverlay = menu.querySelector('.menu-overlay');
    menu.classList.toggle('active');
    menu.querySelectorAll('[data-nav-order]').forEach(function(el, idx) {
        el.classList.remove('hover');
    });
    menu.querySelector('.panel.home [data-nav-order="1"]').classList.toggle('hover', true);
    setTimeout(function() {
        menu.querySelector('label[for="menu-panel-' + (menu.classList.contains('active') ? "4" : "unchecker") + '"]').click();
    }, 350);
}

function moveNav(direction, menu) {
    const menuLabels            = menu.querySelectorAll('.main-nav label');
    const currentActiveLabel    = menu.querySelector('.main-nav label.active');
    const currentHoverElem      = menu.querySelector('.hover');
    let newActiveLabel, 
        newPos, 
        newHoverElem;
        
    switch (direction) {
        case 'left':
            newActiveLabel = currentActiveLabel.previousElementSibling != null ? currentActiveLabel.previousElementSibling : menuLabels[menuLabels.length - 1];
            break;
        case 'right':
            newActiveLabel = currentActiveLabel.nextElementSibling != null ? currentActiveLabel.nextElementSibling : menuLabels[0];
            break;
        case 'top':
            if (!(currentHoverElem))
                break;
            newPos = parseInt(currentHoverElem.getAttribute('data-nav-order')) - 1;
            newHoverElem = menu.querySelector(':checked + .panel [data-nav-order="' + newPos + '"]');
            if (!(newHoverElem)) {
                let allHoverableElems = menu.querySelectorAll(':checked + .panel [data-nav-order]');
                newHoverElem = allHoverableElems[allHoverableElems.length - 1];
            }
            newHoverElem.classList.add('hover');
            currentHoverElem.classList.remove('hover');
            break;
        case 'bottom':
            if (!(currentHoverElem))
                break;
            newPos = parseInt(currentHoverElem.getAttribute('data-nav-order')) + 1;
            newHoverElem = menu.querySelector(':checked + .panel [data-nav-order="' + newPos + '"]');
            if (!(newHoverElem)) 
                newHoverElem = menu.querySelector(':checked + .panel [data-nav-order="1"]');
             
            newHoverElem.classList.add('hover');
            currentHoverElem.classList.remove('hover');
            break;
    }
    if (!!(newActiveLabel)) {
        newActiveLabel.click();
        if (!!(currentHoverElem)) 
            currentHoverElem.classList.remove('hover');

        let thisPanelFirstHover = menu.querySelector(':checked + .panel [data-nav-order="1"]');
        if (!!(thisPanelFirstHover))
            thisPanelFirstHover.classList.add('hover');
    }
}

// taken from https://stackoverflow.com/a/23230280/3589756 to handle swipe on phone
var xDown = null;                                                        
var yDown = null;                                                        

function handleTouchStart(evt) {                                         
    xDown = evt.touches[0].clientX;                                      
    yDown = evt.touches[0].clientY;                                      
};                                                

function handleTouchMove(evt) {
    if ( ! xDown || ! yDown ) {
        return;
    }

    var xUp = evt.touches[0].clientX;                                    
    var yUp = evt.touches[0].clientY;

    var xDiff = xDown - xUp;
    var yDiff = yDown - yUp;

    if ( Math.abs( xDiff ) > Math.abs( yDiff ) ) {/*most significant*/
        if ( xDiff > 0 ) {
            /* left swipe */ 
            moveNav('right', document.getElementById('menu'));
        } else {
            /* right swipe */
            moveNav('left', document.getElementById('menu'));
        } 
    }
    else {
        if ( yDiff > 0 ) {
            /* up swipe */ 
            document.querySelector('.menu-overlay').classList.add('folded');
        } else { 
            /* down swipe */
            document.querySelector('.menu-overlay').classList.remove('folded');
        }    
      }
    /* reset values */
    xDown = null;
    yDown = null;                                             
};

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};

/* BEGIN DEMO JS ONLY */
const bouchonTrainings = {
    horses: [
        {    
            name: 'A354',
            pic: 'https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Sophie.jpg'
        },
        {    
            name: 'S235',
            pic: 'https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Digit.jpg'
        },
        {    
            name: 'B293',
            pic: 'https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Sparky-150x150.jpg'
        },
        {    
            name: 'V20',
            pic: 'https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Sparky-150x150.jpg'
        },
    ],
    riders: ['Valentin R.', 'Erwan M.', 'Thomas B.', 'Guillaume D.'],

}; 
const trainingTpl = `
<div id="{{randomId}}" class="block full training">
    <a data-nav-order="{{navOrder}}" href="#" class="rich-link smalltext">
        <span class="link-image">
            <img src="{{horsePic}}" alt="horse's name" width="100%" />
        </span>
        <p class="link-title">
            <span class="caption">{{hour}}</span>
            <span>Horse: {{horseName}} | Rider: {{riderName}}</span>
        </p>
    </a>
</div>`;

const $calendar = $('#menu-calendar');
const trainingCalendarParams = {
    allDaySlot: false,
    contentHeight: 'auto',
    dayClick: function(start, end, event, view) {
        const $menu = $('#menu');
        $menu.find('.hover').removeClass('hover');
        $menu.find(':checked + .panel [data-nav-order="2"]').addClass('hover');
        let nbTrainings         = Math.floor(Math.random() * Math.floor(4));
        let nbTrainingsString   = nbTrainings + " " + (nbTrainings < 2 ? "training" : "trainings");
        let dayString           = start.isSame(new Date(), 'day') ? "today" : "on " + start.format('MMMM Do'); 
        $('#calendar-day-btn').find('.nb-trainings').text(nbTrainingsString).end()
                              .find('.date-trainings').text(dayString);

        $('#trainings-section .training').remove();
        for(let i = 0; i < nbTrainings; i++) {
            let randomBouchonIdxOne = Math.floor(Math.random() * Math.floor(3));
            let randomBouchonIdxTwo = Math.floor(Math.random() * Math.floor(3));
            let newTraining         = (' ' + trainingTpl).slice(1); // method to clone the string
            let hrs                 = Math.floor(Math.random() * Math.floor(12));
            let min                 = Math.floor(Math.random() * Math.floor(59));
            let randomId            = bouchonTrainings.horses[randomBouchonIdxOne].name + Math.floor(Math.random() * 100);
            const randomTime = (hrs < 10 ? '0' : '') + hrs + ':' + (min < 10 ? '0' : '') + min + (Math.random >= 0.5 ? 'AM' : 'PM');
            newTraining = newTraining.replace('{{navOrder}}', i+3)
                                     .replace('{{randomId}}', randomId)
                                     .replace('{{horsePic}}', bouchonTrainings.horses[randomBouchonIdxOne].pic)
                                     .replace('{{horseName}}', bouchonTrainings.horses[randomBouchonIdxOne].name)
                                     .replace('{{riderName}}', bouchonTrainings.riders[randomBouchonIdxTwo])
                                     .replace('{{hour}}', randomTime);
            $('#trainings-section').append(newTraining);
            setTimeout(function() {
                $('#' + randomId + ' > a').css({'transform': 'translateX(0px)'});
            }, 5);
        }
    },
    defaultView: 'month',
    displayEventTime: false,
    editable: false,
    eventAfterAllRender: function () {
        
    },
    eventConstraint: {
        start: moment().format('YYYY-MM-DD'),
        end: moment(moment())
    },
    eventLimit: true,
    events: {},
    firstDay: 1,
    header: {
        center: '',
        left: 'title',
        right: 'prev, next' //'agendaWeek, month, year'
    },
    lazyFetching: false,
    loading: function () {
        
    },
    longPressDelay: 50,
    selectable: true, 
    selectOverlap: false,
    slotDuration: '00:120:00',
    slotEventOverlap: false,
    slotLabelFormat: 'HH[h]',
    slotLabelInterval: {hours: 2},
    snapDuration: '00:60:00',
    timeFormat: 'H[h](:mm)',
    titleFormat: 'MMMM', 
    eventOverlap: function (stillEvent, movingEvent) {
        return stillEvent.allDay && movingEvent.allDay;
    },
    viewRender: function (view) {
        
    },
    views: {
        month: {
            columnFormat: 'dd'
        }
    }
};

$(document).ready(function() {
    $calendar.fullCalendar(trainingCalendarParams);
})
/* END DEMO JS ONLY */