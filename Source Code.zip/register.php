<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>OneUiX | Create account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="./assets/style.css">
    <link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
    <link rel="icon" type="image/x-icon" href="logo.png">
  </head>
  <body>
    <?php
    if(isset($_POST["submit"])){
      require("mysql.php");
      $stmt = $mysql->prepare("SELECT * FROM accounts WHERE USERNAME = :user"); //Username überprüfen
      $stmt->bindParam(":user", $_POST["username"]);
      $stmt->execute();
      $count = $stmt->rowCount();
      if($count == 0){
        //Username ist frei
        if($_POST["pw"] == $_POST["pw2"]){
          //User anlegen
          $stmt = $mysql->prepare("INSERT INTO accounts (USERNAME, PASSWORD) VALUES (:user, :pw)");
          $stmt->bindParam(":user", $_POST["username"]);
          $hash = password_hash($_POST["pw"], PASSWORD_BCRYPT);
          $stmt->bindParam(":pw", $hash);
          $stmt->execute();
          echo "<p style='color:green; margin-top: 27%;'>Your account has been created! You can login now.</p>";
        } else {
          echo "<p style='color:red; margin-top: 27%;'>Passwords did not match!</p>";
        }
      } else {
        echo "<p style='color:red; margin-top: 27%;'>Email is already taken!</p>";
      }
    }
     ?>
     <div class="form_div">
    <h1>Create account</h1>
    <form action="register.php" method="post">
      <input type="email" name="username" placeholder="E-Mail" required>
      <br>
      <br>
      <input type="password" name="pw" placeholder="Password" required>
      <br>
      <br>
      <input type="password" name="pw2" placeholder="repeat Password" required>
      <br>
      <br>
      <br>
      <button type="submit" name="submit" title="Create account" ><i class="material-icons">how_to_reg</i></button>
    </form>
    <br>
    <a href="index.php" title="Login with existing account"><i class="material-icons">login</i></a>
    </div>
  </body>
</html>
