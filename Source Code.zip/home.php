<?php
		session_start();
		if(!isset($_SESSION["username"])){
 		header("Location: index.php");
  		exit;
		}
 	?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width">
 	 <title>OneUiX | Home</title>
  	<link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css'>
	<link rel="stylesheet" href="./assets/home.css">
	<link rel="stylesheet" href="./assets/home_scr.css">
	<link rel="icon" type="image/x-icon" href="logo.png">
</head>
<body>
<!-- partial:index.partial.html -->
<div id="menu">
		<div class="menu-overlay">
      <i class="icon material-icons">close</i>  
    </div>
		<div class="menu-container">
			<div class="main-nav">
				<label for="menu-panel-1"  tabindex="-1"><i class="icon material-icons">settings</i></label>
				<label for="menu-panel-2"  tabindex="-1"><i class="icon material-icons">settings_remote</i></label>
				<label for="menu-panel-3"  tabindex="-1"><i class="icon material-icons">power_settings_new</i></label>
				<label for="menu-panel-4"  tabindex="-1" class="active"><i class="icon material-icons">apps</i></label>
				<label for="menu-panel-5"  tabindex="-1"><i class="icon material-icons">notifications_active</i></label>
				<label for="menu-panel-6"  tabindex="-1"><i class="icon material-icons">date_range</i></label>
				<label for="menu-panel-7"  tabindex="-1"><i class="icon material-icons">people</i></label>
			</div>
			<div class="menu-inner">
				<input type="radio" id="menu-panel-1" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable settings">
					<section class="section-flex">
						<h2 class="panel-title">Settings</h2>
					</section>
				</div>
				<input type="radio" id="menu-panel-2" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable devices">
					<section class="section-flex">
						<h2 class="panel-title">Devices Management</h2>
					</section>
				</div>
				<input type="radio" id="menu-panel-3" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable Data">
					<section class="section-flex">
						<h2 class="panel-title">Power</h2>
						<br>
						<br>
						<a data-nav-order="1" href="#" class="rich-link">
							<span class="link-image">
								<i class="icon material-icons">power_settings_new</i>
							</span>
							<span class="link-title">
								Shutdown
							</span>
						</a>
						<a data-nav-order="2" href="#" class="rich-link">
							<span class="link-image">
								<i class="icon material-icons">restart_alt</i>
							</span>
							<span class="link-title">
								Restart
							</span>
						</a>
						<img src="logo.png" class="x_logo">
						<p class="x_version">version 3.5.12342343.453545.2435245</p>
					</section>
				</div>
				<input type="radio" id="menu-panel-4" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable home">
					<section class="section-flex">
						<div class="block full"><button data-nav-order="1"><i class="icon material-icons">home</i> Home</button></div>
						<div class="block third"><button data-nav-order="2" class="hover-text"><i class="material-icons">dashboard</i><span>Dashboard</span></button></div>
						<div class="block third"><button data-nav-order="3" class="hover-text"><i class="material-icons">search</i><span>Search</span></button></div>
						<div class="block third"><button  data-nav-order="4" class="hover-text"><i class="material-icons">location_searching</i><span>Go to (Ctrl+K)</span></button></div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<h3>My Pinned Actions <button data-nav-order="5"><i class="icon material-icons">edit</i></button></h3>
						</div>
						<div class="block full">
							<a data-nav-order="6" class="rich-link" href="#">
								<span class="link-image">
									<i class="icon material-icons">playlist_add_check</i>
								</span>
								<span class="link-title">
									Verify & Disseminate
								</span>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="7" class="rich-link" href="#">
								<span class="link-image">
									<i class="icon material-icons">history</i>
								</span>
								<span class="link-title">
									Latest data
								</span>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="8" class="rich-link" href="#">
								<span class="link-image">
									<i class="icon material-icons">tap_and_play</i>
								</span>
								<span class="link-title">
									RFID Mapping
								</span>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="9" class="rich-link" href="#">
								<span class="link-image">
									<i class="icon material-icons">event_note</i>
								</span>
								<span class="link-title">
									Rémi C. Schedules
								</span>
							</a>
						</div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<h3>About me</h3>
						</div>
						<div class="block full">
							<a data-nav-order="10" href="#" class="rich-link">
								<span class="link-image">
									<i class="icon material-icons">tag_faces</i>
								</span>
								<span class="link-title">
									My profile
								</span>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="11" href="logout.php" class="rich-link">
								<span class="link-image">
									<i class="icon material-icons">logout</i>
								</span>
								<span class="link-title">
									Log out
								</span>
							</a>
						</div>
					</section>
				</div>
				<input type="radio" id="menu-panel-5" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable notifications">
					<section class="section-flex">
						<h2 class="panel-title">Notifications</h2>
					</section>
					<section class="section-flex">
						<div class="block full">
							<a data-nav-order="1" href="#" class="rich-link">
								<span class="link-image">
									+32
								</span>
								<span class="link-title">
									Check all notifications
								</span>
							</a>
						</div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<h3>Today</h3>
						</div>
						<div class="block full">
							<a data-nav-order="2" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">av_timer</i>
								</span>
								<p class="link-title">
									<span class="caption">10:00AM</span>
									<span>Rider Adrien L. finished A345's training.</span>
								</p>
							</a>
							<a data-nav-order="3" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">av_timer</i>
								</span>
								<p class="link-title">
									<span class="caption">9:30AM</span>
									<span>Rider Sami P. finished B432's training.</span>
								</p>
							</a>
							<a data-nav-order="4" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">warning</i>
								</span>
								<p class="link-title">
									<span class="caption">8:45AM</span>
									<span>Device #1345 seems faulty. Please check its state.</span>
								</p>
							</a>
						</div>
					</section>
					<section class="section-flex">
						<div class="block full">
							<h3>Yesterday</h3>
						</div>
						<div class="block full">
							<a data-nav-order="5" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">verified_user</i>
								</span>
								<p class="link-title">
									<span class="caption">4:00PM</span>
									<span>Device #5433 has been mapped to rider Sami P.</span>
								</p>
							</a>
							<a data-nav-order="6" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">slideshow</i>
								</span>
								<p class="link-title">
									<span class="caption">3:20PM</span>
									<span>A replay is available for horse A43D</span>
								</p>
							</a>
							<a data-nav-order="7" href="#" class="rich-link smalltext">
								<span class="link-image">
									<i class="icon material-icons">list</i>
								</span>
								<p class="link-title">
									<span class="caption">8:45AM</span>
									<span>User Youness M. added a new activtiy.</span>
								</p>
							</a>
						</div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<a data-nav-order="8" href="#" class="rich-link">
								<span class="link-image">
									<i class="icon material-icons">tune</i>
								</span>
								<p class="link-title">
									Notification preferences
								</p>
							</a>
						</div>
					</section>
				</div>
				<input type="radio" id="menu-panel-6" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable schedules">
					<section class="section-flex">
						<h2 class="panel-title">Schedules</h2>
					</section>
					<section id="trainings-section" class="section-flex">
						<div class="block full">
							<a data-nav-order="1" href="#">See the full agenda</a>
						</div>
						<div class="block full">
							<div id="menu-calendar"></div>
						</div>
						<div class="block full">
							<a id="calendar-day-btn" data-nav-order="2" href="#"><span class="nb-trainings">3 trainings</span> <span class="date-trainings">today</span>: </a>
						</div>
						<div class="block full training">
							<a data-nav-order="3" href="#" class="rich-link smalltext" style="transform: translateX(0px)">
								<span class="link-image">
									<img src="https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Sophie.jpg" alt="horse's name" width="100%" />
								</span>
								<p class="link-title">
									<span class="caption">9:00AM</span>
									<span>Horse: A354 | Rider: Valentin R.</span>
								</p>
							</a>
						</div>
						<div class="block full training">
							<a data-nav-order="4" href="#" class="rich-link smalltext" style="transform: translateX(0px)">
								<span class="link-image">
									<img src="https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Digit.jpg" alt="horse's name" width="100%" />
								</span>
								<p class="link-title">
									<span class="caption">9:30AM</span>
									<span>Horse: S235 | Rider: Thomas B.</span>
								</p>
							</a>
						</div>
						<div class="block full training">
							<a data-nav-order="5" href="#" class="rich-link smalltext" style="transform: translateX(0px)">
								<span class="link-image">
									<img src="https://bransbyhorses.co.uk/wp-content/uploads/2016/03/Sparky-150x150.jpg" alt="horse's name" width="100%" />
								</span>
								<p class="link-title">
									<span class="caption">11:15AM</span>
									<span>Horse: B293 | Rider: Erwan M.</span>
								</p>
							</a>
						</div>
					</section>
				</div>
				<input type="radio" id="menu-panel-7" name="main-nav-panels" tabindex="-1" />
				<div class="panel scrollable people">
					<section class="section-flex">
						<h2 class="panel-title">Users</h2>
					</section>
					<section class="section-flex">
						<div class="block full">
							<h3>Assistant Trainers</h3>
						</div>
						<div class="block full">
							<a data-nav-order="1" href="#" class="rich-link no-line-height">
								<ul class="avatar-list">
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li class="more">+6</li>
								</ul>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="2" href="#">Add a new assistant trainer</a>
						</div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<h3>Riders</h3>
						</div>
						<div class="block full">
							<a data-nav-order="3" href="#" class="rich-link no-line-height">
								<ul class="avatar-list">
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li><img src="profilepic.jfif" alt="User's name" width="100%" /></li>
									<li class="more">+2</li>
								</ul>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="4" href="#">Add a new rider</a>
						</div>
					</section>
					<hr>
					<section class="section-flex">
						<div class="block full">
							<h3>Roles & Permissions</h3>
						</div>
						<div class="block full">
							<a data-nav-order="5" href="#" class="rich-link">
								<span class="link-image">
									<i class="icon material-icons">verified_user</i>
								</span>
								<p class="link-title">
									Manage users role
								</p>
							</a>
						</div>
						<div class="block full">
							<a data-nav-order="6" href="#" class="rich-link">
								<span class="link-image">
									<i class="icon material-icons">access_time</i>
								</span>
								<p class="link-title">
									Check access logs
								</p>
							</a>
						</div>
					</section>
				</div>
				<input type="radio" id="menu-panel-unchecker" name="main-nav-panels" tabindex="-1" />
			</div>
		</div>
		<label for="menu-panel-unchecker"></label>
	</div>

<!-- BEGIN DEMO ONLY -->

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js'></script>
<script src='https://cdn.rawgit.com/tiansh/ya-simple-scrollbar/master/ya-simple-scrollbar.min.js'></script><script  src="./script.js"></script>

<div class="home_scr">
	<div class="home_nav">

	</div>
	<div class="home_content">

	</div>
	<div class="home_footer">

	</div>
</div>

</body>
</html>
