<?php
		session_start();
		if(!isset($_SESSION["username"])){
 		header("Location: index.php");
  		exit;
		}
 	?>
<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>OneUiX | Loading...</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="icon" type="image/x-icon" href="logo.png">
    <meta http-equiv='refresh' content='10; URL=./home.php'>
</head>
<body>
<!-- partial:index.partial.html -->
<div class="box">
     OneUiX is starting...
</div>
<!-- partial -->
  
</body>
</html>
